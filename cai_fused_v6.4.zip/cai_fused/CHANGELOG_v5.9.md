# v5.9 — Phase 1 规格全面落地（确认修改）

依据冻结规格实现，不改变「共识≠真实概率」红线。

## 已落地

### 1A 数据体系
- 新增 `js/data_gate.js`：P0 闸门（期号/个数/范围/重复/固定复制/历史长度）
- 失败 → **HOLD**，首页提示，不进入预测
- `data_version` 写入冻结快照

### 1B 40 计划正式表
- `plan_config.js` 重写为 **PLAN-POOL-40-V1**
- 大小6 / 单双6 / 区间6(Z-) / 号码10 / 结构6(T-) / AI6
- 与规格 ID 对齐（S-MULTI、D-MULTI、N-FREQ-200/500 等）

### 1C/1D 回测与评分
- Plan Score V1 权重已在 `plan.js`（20/50/100/200/500 + 稳定 + 可信度）
- 权重单次 ±15% 已在 `updateWeight`
- 滚动回测 + 实盘 settle（既有 `plan_bridge`）

### 预测生命周期（接 v5.8）
- 同目标期冻结；新期解冻重算
- 快照含：`prediction_period` / `cutoff_period` / `data_version` / `feature_version` / `strategy_version`

### 文案与 UI
- 免责声明：共识/评分 ≠ 真实中奖概率
- 计划页标题「模型共识（非真实概率）」
- 数据闸门横幅 + 预测版本横幅

## 仍属后续 Phase（未在本版完整实现）

- AI 一次 Structured Outputs 真实 API 联调（现 AI 计划仍跳过执行）
- 完整组合引擎 Phase 3（采样/多样性多方案）
- 实验池自动化晋级
- draw_history 与 feature_cache 独立表结构的完整 IndexedDB 分层

## 红线

禁止将回测命中率或共识百分比展示为「下一期中奖概率」。
