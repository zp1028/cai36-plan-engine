# v6.0 — 后续 Phase 一并完成

在 v5.9 Phase1 基础上补齐：

## 1. AI 体系（可回测、可降级）

- 对齐计划 ID：`AI-STAT` … `AI-SYNTH`
- 新增 `local_ai.js`：无 API Key 时用**本地启发式**生成与 Structured Schema 对齐的六路输出
- 程序校验 `validateStructured`；失败则丢弃，不污染主路径
- 写入 `PlanStore.ai_history`；AI 权重软上限 0.15
- 既有 `ai_plan.js` 保留真实 API / Schema 路径，可在有 Key 时接入

## 2. 组合引擎 Phase3（既有 combo_generator）

- 继续：Top 候选 → 多策略权重 → 结构软约束 → 去重 / 变化度
- 计划页展示组合与变化度

## 3. 实验池自动晋级

- `sample_size ≥ 20` 且 `score ≥ 60` → `promoteFromExperiment`
- 每轮 `runPostPipeline` 自动检查

## 4. 分层 IndexedDB（`plan_store.js`）

| Store | 用途 |
|-------|------|
| strategy_history | 计划评分快照 |
| model_weights | 权重时间序列 |
| prediction_snapshots | 预留 |
| ai_history | AI 结构化输出归档 |

与 CacheDB（开奖）分离，避免冲突。

## 红线

本地 AI / 远程 AI 输出均为**模型评分与倾向**，不是真实中奖概率。
