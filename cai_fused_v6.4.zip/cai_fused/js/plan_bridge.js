/**
 * plan_bridge.js - 计划引擎集成层 v5.7.2
 * 优化清单：
 * 1. 实盘自动 settle（新开奖）
 * 2. 回测性能（首次全量 / 之后增量，窗口 50，节流）
 * 3. 缺失算法：AI 类跳过；其余映射到近似算法
 * 4. 计划状态 localStorage 持久化
 * 5. 与 settlePredictions / 换彩种 联动
 */
const PlanIntegration = (function() {
  'use strict';

  const STORAGE_KEY = 'cai_plan_state_v1';
  const BACKTEST_N = 30;
  const THROTTLE_MS = 3000;

  let initialized = false;
  let lastSequences = null;
  let lastConsensus = null;
  let lastNumberProb = null;
  let lastCombos = null;
  let lastRankings = [];
  let isUpdating = false;
  let lastUpdateAt = 0;
  let lastSettledIssue = null;
  let lastLotCode = null;
  let fullBacktestDone = false;

  // 缺失算法 → 近似实现
  const ALGO_FALLBACK = {
    STAT: 'FREQ',
    STRUCT: 'FREQ',
    FILTER: 'FREQ',
    EVAL: 'FREQ',
    ANOM: 'FREQ',
    SYNTH: 'FREQ',
    MSF: 'FREQ'
  };
  const STRATEGY_VERSION = (typeof PlanConfig !== 'undefined' && PlanConfig.STRATEGY_VERSION)
    ? PlanConfig.STRATEGY_VERSION : 'PLAN-POOL-40-V1';

  function convertRow(row) {
    if (!row) return null;
    let nums = [];
    if (Array.isArray(row['号码'])) nums = row['号码'];
    else if (Array.isArray(row.numbers)) nums = row.numbers;
    else if (Array.isArray(row.result)) nums = row.result;
    else if (typeof row['号码'] === 'string') {
      nums = row['号码'].split(/[,，\s]+/).filter(Boolean);
    } else {
      // 号1..号20 回退
      for (let i = 1; i <= 20; i++) {
        const v = row['号' + i];
        if (v != null && v !== '') nums.push(v);
      }
    }
    const clean = [];
    const seen = new Set();
    for (const n of nums) {
      const x = parseInt(n, 10);
      if (!isNaN(x) && x >= 1 && x <= 80 && !seen.has(x)) {
        seen.add(x);
        clean.push(x);
      }
    }
    // 至少 10 个有效号即可建序列（快乐8 正常为 20）
    if (clean.length < 10) return null;
    while (clean.length < 20) clean.push(clean[clean.length - 1]); // 占位避免引擎崩溃
    const issue = String(row['期号'] || row.issue || '');
    if (!issue) return null;
    return {
      issue: issue,
      numbers: clean.slice(0, 20),
      result: clean.slice(0, 20),
      sum: row['和值'] != null ? Number(row['和值']) : clean.reduce((a, b) => a + b, 0),
      size: row['大小'] || null,
      oddEven: row['单双'] || null,
      time: row['开奖时间'] || row.time || null
    };
  }

  function convertHistory(rows) {
    if (!Array.isArray(rows)) return [];
    return rows.map(convertRow).filter(Boolean);
  }

  // ---------- 持久化 ----------
  function persistKey(lotCode) {
    return STORAGE_KEY + '_' + (lotCode || 'default');
  }

  function saveState(lotCode) {
    if (typeof PlanPool === 'undefined' || !initialized) return;
    try {
      const plans = PlanPool.getAllPlans().map(p => ({
        plan_id: p.plan_id,
        status: p.status,
        score: p.score,
        weight: p.weight,
        sample_size: p.sample_size,
        valid_sample_size: p.valid_sample_size,
        rates: p.rates,
        excess: p.excess,
        current_streak: p.current_streak,
        max_streaks: p.max_streaks,
        credibility: p.credibility,
        // 只保留最近 120 条历史，控制体积
        history: (p.history || []).slice(-120)
      }));
      const payload = {
        v: 1,
        lotCode: lotCode,
        savedAt: Date.now(),
        lastSettledIssue: lastSettledIssue,
        plans: plans
      };
      localStorage.setItem(persistKey(lotCode), JSON.stringify(payload));
    } catch (e) {
      console.warn('[PlanIntegration] 持久化失败', e);
    }
  }

  function loadState(lotCode) {
    try {
      const raw = localStorage.getItem(persistKey(lotCode));
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }

  function applySavedState(saved) {
    if (!saved || !saved.plans) return false;
    let applied = 0;
    saved.plans.forEach(s => {
      const plan = PlanPool.getPlan(s.plan_id);
      if (!plan) return;
      try {
        if (s.status) plan.status = s.status;
        if (s.score != null) plan.score = s.score;
        if (s.weight != null) plan.weight = s.weight;
        if (s.sample_size != null) plan.sample_size = s.sample_size;
        if (s.valid_sample_size != null) plan.valid_sample_size = s.valid_sample_size;
        if (s.rates) plan.rates = s.rates;
        if (s.excess) plan.excess = s.excess;
        if (s.current_streak) plan.current_streak = s.current_streak;
        if (s.max_streaks) plan.max_streaks = s.max_streaks;
        if (s.credibility != null) plan.credibility = s.credibility;
        if (Array.isArray(s.history)) plan.history = s.history;
        applied++;
      } catch (e) {}
    });
    if (saved.lastSettledIssue) lastSettledIssue = saved.lastSettledIssue;
    console.log('[PlanIntegration] 恢复持久化状态:', applied, '个计划');
    return applied > 0;
  }

  // ---------- 初始化 ----------
  function ensureInit(lotCode) {
    if (initialized && lastLotCode === lotCode) return true;
    if (typeof PlanConfig === 'undefined' || typeof PlanPool === 'undefined') {
      console.warn('[PlanIntegration] 计划模块未加载');
      return false;
    }
    try {
      // 换彩种时重新初始化
      PlanPool.initialize(PlanConfig.PLANS);
      fullBacktestDone = false;
      lastSettledIssue = null;

      const all = PlanPool.getAllPlans();
      all.forEach(plan => {
        if (plan.status === 'new' && plan.category !== 'AI') {
          plan.setStatus('observing', '启动：进入观察池');
        }
      });

      const saved = loadState(lotCode);
      if (saved && saved.plans && saved.plans.length) {
        applySavedState(saved);
        // 有持久化样本则视为已回测，避免重复重算
        const anySample = PlanPool.getAllPlans().some(p => (p.sample_size || 0) >= 10);
        if (anySample) fullBacktestDone = true;
      }

      initialized = true;
      lastLotCode = lotCode;
      console.log('[PlanIntegration] 计划池就绪 lot=', lotCode, 'plans=', all.length, 'backtestDone=', fullBacktestDone);
      return true;
    } catch (e) {
      console.error('[PlanIntegration] 初始化失败:', e);
      return false;
    }
  }

  function buildActualResult(sequences, index) {
    return {
      '大小': sequences.sizeDirection[index],
      '单双': sequences.oddEvenDirection[index],
      '区间': {
        '一区': sequences.zone1[index],
        '二区': sequences.zone2[index],
        '三区': sequences.zone3[index],
        '四区': sequences.zone4[index]
      },
      '号码': sequences.numbers[index],
      '结构': {
        sum: sequences.sum[index],
        span: sequences.span[index],
        consecutive: sequences.consecutive[index],
        ac: sequences.ac[index]
      }
    };
  }

  function resolveAlgorithm(plan) {
    const alg = plan.algorithm;
    if (typeof PlanExecutor !== 'undefined' && PlanExecutor.Algorithms && PlanExecutor.Algorithms[alg]) {
      return alg;
    }
    return ALGO_FALLBACK[alg] || null;
  }

  function executePlan(plan, sequences, idx) {
    if (plan.category === 'AI') return null;
    const alg = resolveAlgorithm(plan);
    if (!alg) return null;
    // 临时替换 algorithm 以走已有实现
    const orig = plan.algorithm;
    try {
      if (alg !== orig) plan.algorithm = alg;
      return PlanExecutor.execute(plan, sequences, idx);
    } catch (e) {
      return null;
    } finally {
      plan.algorithm = orig;
    }
  }

  function runRollingBacktest(sequences, currentIndex, backtestN) {
    const start = Math.max(20, currentIndex - backtestN);
    let settled = 0;
    const plans = PlanPool.getAllPlans();

    for (let i = start; i < currentIndex; i++) {
      const issue = sequences.issues[i];
      for (const plan of plans) {
        if (plan.status === 'eliminated' || plan.status === 'experiment') continue;
        if (plan.category === 'AI') continue;
        try {
          const prediction = executePlan(plan, sequences, i);
          if (prediction != null) {
            plan.predict(prediction, issue, i, 'backtest', plan.weight || 0.1, null);
          }
        } catch (e) {}
      }

      const actualIdx = i + 1;
      if (actualIdx > currentIndex) break;
      const actual = buildActualResult(sequences, actualIdx);

      for (const plan of plans) {
        if (!plan.current_prediction) continue;
        if (plan.status === 'eliminated') continue;
        try {
          const catActual = actual[plan.category] !== undefined ? actual[plan.category] : actual;
          plan.settle(catActual);
        } catch (e) {}
      }

      for (const plan of plans) {
        try { plan.calculateScore(); } catch (e) {}
      }
      // 每 10 期做一次状态转换，减少开销
      if (settled % 10 === 9) {
        try { PlanPool.processStatusTransitions(); } catch (e) {}
      }
      settled++;
    }
    try { PlanPool.processStatusTransitions(); } catch (e) {}
    console.log('[PlanIntegration] 回测完成:', settled, '期');
    return settled;
  }

  /** 仅对指定已开奖期号做 settle（实盘） */
  function settleIssue(sequences, issueStr) {
    if (!sequences || !issueStr) return false;
    const idx = sequences.issues.indexOf(String(issueStr));
    if (idx < 0) return false;

    const actual = buildActualResult(sequences, idx);
    const plans = PlanPool.getAllPlans();
    let n = 0;
    for (const plan of plans) {
      if (!plan.current_prediction) continue;
      if (plan.status === 'eliminated') continue;
      // 只结算预测期号 <= 当前开奖期号
      const predIssue = String(plan.current_prediction.issue || '');
      try {
        if (parseInt(predIssue, 10) > parseInt(issueStr, 10)) continue;
      } catch (e) {
        if (predIssue > issueStr) continue;
      }
      try {
        const catActual = actual[plan.category] !== undefined ? actual[plan.category] : actual;
        plan.settle(catActual);
        plan.calculateScore();
        n++;
      } catch (e) {}
    }
    try { PlanPool.processStatusTransitions(); } catch (e) {}
    lastSettledIssue = String(issueStr);
    console.log('[PlanIntegration] 实盘 settle', issueStr, 'plans=', n);
    return n > 0;
  }

  function predictCurrent(sequences, currentIndex) {
    const currentIssue = sequences.issues[currentIndex];
    const getPlanPredictionFn = (plan) => {
      try {
        return executePlan(plan, sequences, currentIndex);
      } catch (e) {
        return null;
      }
    };
    // predictAll 签名: (issue, cutoffPeriod, dataVersion, getPlanPredictionFn)
    PlanPool.predictAll(currentIssue, currentIndex, 'live_' + Date.now(), (plan, issue, cutoff) => getPlanPredictionFn(plan));
  }

  function computeDownstream(sequences, currentIndex) {
    PlanPool.updateAllWeights({});
    let activePlans = PlanPool.getActivePlans();
    if (!activePlans.length) {
      activePlans = PlanPool.getAllPlans().filter(p => p.status !== 'eliminated' && p.category !== 'AI');
    }
    try {
      lastConsensus = ConsensusEngine.calculateAllConsensus(activePlans);
    } catch (e) {
      lastConsensus = null;
    }
    try {
      lastNumberProb = NumberProbEngine.calculateNumberProbabilities(
        activePlans, lastConsensus, sequences, currentIndex, null
      );
    } catch (e) {
      lastNumberProb = null;
    }
    try {
      const structurePlans = activePlans.filter(p => p.category === '结构');
      lastCombos = ComboGenerator.generateCombos(
        lastNumberProb || { scores: {}, top40: [] },
        lastConsensus,
        structurePlans,
        sequences,
        currentIndex
      );
    } catch (e) {
      lastCombos = null;
    }

    let rankings = PlanPool.getRankings('score');
    if (!rankings || !rankings.length) {
      rankings = PlanPool.getAllPlans()
        .filter(p => p.status !== 'eliminated')
        .sort((a, b) => (b.score || 0) - (a.score || 0))
        .map((plan, index) => ({
          rank: index + 1,
          plan_id: plan.plan_id,
          plan_name: plan.plan_name,
          category: plan.category,
          algorithm: plan.algorithm,
          status: plan.status,
          score: plan.score,
          sample_size: plan.sample_size,
          rates: plan.rates,
          current_streak: plan.current_streak,
          weight: plan.weight
        }));
    }
    lastRankings = rankings;
  }

  function buildSequencesFromHistory(historyRows) {
    const draws = convertHistory(historyRows);
    if (draws.length < 10) return null;
    return FeatureEngine.buildSequences(draws);
  }

  /**
   * 主更新入口
   * @param {Array} historyRows
   * @param {{force?: boolean, lotCode?: string}} opts
   */
  async function updateFromHistory(historyRows, opts) {
    opts = opts || {};
    // 防止上次异常导致 isUpdating 卡死
    if (isUpdating && Date.now() - lastUpdateAt > 60000) {
      console.warn('[PlanIntegration] 重置卡住的 isUpdating');
      isUpdating = false;
    }
    if (isUpdating && !opts.force) return null;
    if (isUpdating && opts.force) isUpdating = false;

    const lotCode = opts.lotCode
      || (typeof AppState !== 'undefined' && AppState.currentConfig && AppState.currentConfig.code)
      || 'default';

    if (!opts.force && Date.now() - lastUpdateAt < THROTTLE_MS && lastRankings.length > 0 && lastLotCode === lotCode) {
      renderPlanPage();
      return { consensus: lastConsensus, rankings: lastRankings, cached: true };
    }

    if (!historyRows || historyRows.length < 10) {
      showPlanError('历史不足（当前 ' + (historyRows ? historyRows.length : 0) + ' 期），请先在首页加载彩种数据');
      return null;
    }
    if (typeof FeatureEngine === 'undefined' || typeof PlanExecutor === 'undefined') {
      showPlanError('特征/执行模块未加载，请硬刷新页面');
      return null;
    }
    if (!ensureInit(lotCode)) {
      showPlanError('计划池初始化失败');
      return null;
    }

    isUpdating = true;
    try {
      const sequences = buildSequencesFromHistory(historyRows);
      if (!sequences) {
        showPlanError('无法从历史构建特征（号码格式可能异常），已尝试兼容解析');
        return null;
      }
      console.log('[PlanIntegration] sequences OK issues=', sequences.issues.length);
      lastSequences = sequences;
      const currentIndex = sequences.issues.length - 1;

      // 首次或强制：全量回测；否则仅增量
      if (!fullBacktestDone || opts.force) {
        const n = Math.min(BACKTEST_N, currentIndex - 20);
        if (n >= 10) runRollingBacktest(sequences, currentIndex, n);
        fullBacktestDone = true;
      }

      predictCurrent(sequences, currentIndex);
      computeDownstream(sequences, currentIndex);
      runPostPipeline(sequences, currentIndex, lotCode);
      lastUpdateAt = Date.now();

      saveState(lotCode);
      renderPlanPage();

      return {
        consensus: lastConsensus,
        numberProb: lastNumberProb,
        combos: lastCombos,
        rankings: lastRankings
      };
    } catch (err) {
      console.error('[PlanIntegration] 更新失败:', err);
      return null;
    } finally {
      isUpdating = false;
    }
  }

  /**
   * 实盘：新开奖到达时调用（由 app.js settlePredictions 触发）
   * @param {object} rt 最新开奖行（中文键）
   * @param {Array} historyRows 完整历史（应已包含本期）
   */
  function onNewDraw(rt, historyRows) {
    if (!rt) return;
    const issue = String(rt['期号'] || rt.issue || '');
    if (!issue) return;
    if (issue === lastSettledIssue) return;

    const lotCode = (typeof AppState !== 'undefined' && AppState.currentConfig && AppState.currentConfig.code) || 'default';
    if (!ensureInit(lotCode)) return;
    if (!historyRows || historyRows.length < 15) return;
    if (typeof FeatureEngine === 'undefined') return;

    try {
      const sequences = buildSequencesFromHistory(historyRows);
      if (!sequences) return;
      lastSequences = sequences;
      const currentIndex = sequences.issues.length - 1;

      // 1) settle 本期
      settleIssue(sequences, issue);

      // 2) 对最新期重新预测
      predictCurrent(sequences, currentIndex);
      computeDownstream(sequences, currentIndex);
      runPostPipeline(sequences, currentIndex, lotCode);
      lastUpdateAt = Date.now();
      saveState(lotCode);
      renderPlanPage();
      console.log('[PlanIntegration] onNewDraw 完成', issue);
    } catch (e) {
      console.warn('[PlanIntegration] onNewDraw 失败', e);
    }
  }

  /** 换彩种时重置 */
  function resetForLottery(lotCode) {
    initialized = false;
    fullBacktestDone = false;
    lastSettledIssue = null;
    lastRankings = [];
    lastConsensus = null;
    lastNumberProb = null;
    lastCombos = null;
    lastLotCode = null;
    ensureInit(lotCode);
  }


  /**
   * AI 本地/远端结构化输出 + 实验池晋级 + 分层存储
   */
  function runPostPipeline(sequences, currentIndex, lotCode) {
    const issue = sequences.issues[currentIndex];
    const cutoff = currentIndex > 0 ? sequences.issues[currentIndex - 1] : issue;

    // 1) 本地结构化 AI（无 Key 时）；有 AIPlanManager + apiKey 可扩展
    try {
      let usedRemote = false;
      const apiKey = (typeof SysSync !== 'undefined' && SysSync.getAIApiKey)
        ? SysSync.getAIApiKey()
        : (localStorage.getItem('cai_ai_api_key') || '');

      // 有 Key 且存在 AIPlanManager 时尝试远程（失败则降级）
      if (apiKey && typeof AIPlanManager !== 'undefined' && AIPlanManager.executeAIPlans) {
        try {
          AIPlanManager.CONFIG = AIPlanManager.CONFIG || {};
          // 不在此写死 endpoint，仅注入 key 供实现使用
          const remote = AIPlanManager.executeAIPlans(
            lotCode, sequences, currentIndex, lastConsensus, lastRankings, null, apiKey
          );
          if (remote && typeof AIPlanManager.applyAIPredictions === 'function') {
            const planMap = new Map(PlanPool.getAllPlans().map(p => [p.plan_id, p]));
            AIPlanManager.applyAIPredictions(remote, planMap);
            usedRemote = true;
            if (typeof PlanStore !== 'undefined') {
              PlanStore.saveAIHistory({ lotCode, issue, source: 'remote_ai', prompt_version: 'API' }).catch(() => {});
            }
          }
        } catch (e) {
          console.warn('[PlanIntegration] 远程 AI 失败，降级 LocalAI', e);
        }
      }

      if (!usedRemote && typeof LocalAI !== 'undefined') {
        const structured = LocalAI.generateStructured(sequences, currentIndex, lastConsensus, lastRankings);
        const val = LocalAI.validateStructured(structured);
        if (val.ok) {
          const mapped = LocalAI.toPlanPredictions(structured, issue, cutoff);
          applyLocalAIToPlans(mapped, issue, cutoff);
          if (typeof PlanStore !== 'undefined') {
            PlanStore.saveAIHistory({
              lotCode, issue, source: 'local_ai',
              structured: structured,
              prompt_version: 'LOCAL-P01'
            }).catch(() => {});
          }
        } else {
          console.warn('[PlanIntegration] LocalAI 校验失败', val.reason);
        }
      }
    } catch (e) {
      console.warn('[PlanIntegration] AI pipeline', e);
    }

    // 2) 实验池自动晋级
    try {
      if (typeof PlanPool !== 'undefined' && PlanPool.getExperimentPlans) {
        const exps = PlanPool.getExperimentPlans() || [];
        exps.forEach(p => {
          try {
            if (p.sample_size >= 20 && (p.score || 0) >= 60) {
              PlanPool.promoteFromExperiment(p.plan_id);
              console.log('[PlanIntegration] 实验晋级', p.plan_id);
            }
          } catch (e) {}
        });
      }
    } catch (e) {}

    // 3) 分层存储：权重快照 + 策略逐条
    try {
      if (typeof PlanStore !== 'undefined') {
        const weights = {};
        PlanPool.getAllPlans().forEach(p => {
          weights[p.plan_id] = { w: p.weight, s: p.score, st: p.status };
        });
        PlanStore.saveWeightSnapshot(lotCode, issue, weights).catch(() => {});
        // 仅写前 15 条排名减轻写入
        (lastRankings || []).slice(0, 15).forEach(r => {
          PlanStore.addStrategyRecord({
            lotCode, issue, plan_id: r.plan_id,
            score: r.score, status: r.status, weight: r.weight,
            category: r.category
          }).catch(() => {});
        });
      }
    } catch (e) {}
  }

  function applyLocalAIToPlans(mapped, issue, cutoff) {
    if (!mapped || !mapped.predictions) return;
    const preds = mapped.predictions;
    Object.keys(preds).forEach(planId => {
      const plan = PlanPool.getPlan(planId);
      if (!plan) return;
      try {
        // AI 计划也写入 current_prediction，便于共识（若 participate）
        plan.predict(preds[planId], issue, cutoff, 'ai_local', plan.weight || 0.05, null);
        if (plan.status === 'new') {
          plan.setStatus('observing', 'AI本地启发式已产出');
        }
      } catch (e) {}
    });
    // 限幅：AI 权重不超过 0.1 份额意图 — 软限制
    PlanPool.getAllPlans().filter(p => p.category === 'AI').forEach(p => {
      if ((p.weight || 0) > 0.15) p.weight = 0.15;
    });
  }

  // ---------- UI（同前，略增强） ----------
  function rateText(rates, key) {
    if (!rates) return '--';
    const v = rates['r' + key] != null ? rates['r' + key] : rates[key];
    if (v == null || isNaN(v)) return '--';
    return Math.round(v * 100) + '%';
  }

  function streakText(streak) {
    if (!streak) return '--';
    if (typeof streak === 'object') {
      if (streak.win > 0) return '中' + streak.win;
      if (streak.lose > 0) return '挂' + streak.lose;
      return '0';
    }
    return String(streak);
  }

  function escapeHtml(s) {
    if (s == null) return '';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function showPlanError(msg) {
    const tbody = document.getElementById('planTableBody');
    if (tbody) tbody.innerHTML = '<tr class="empty"><td colspan="10">' + (msg || '错误') + '</td></tr>';
    const cons = document.getElementById('consensusBars');
    if (cons) cons.innerHTML = '<div class="loading-text">' + (msg || '等待数据…') + '</div>';
    console.warn('[PlanIntegration]', msg);
  }

  function renderPlanPage() {
    if (!document.getElementById('pagePlan')) return;
    renderPlanTable();
    renderConsensus();
    renderHeatmap();
    renderCombos();
    renderPlanStats();
  }

  function renderPlanTable() {
    const tbody = document.getElementById('planTableBody');
    if (!tbody) return;
    const rankings = lastRankings || [];
    if (!rankings.length) {
      tbody.innerHTML = '<tr class="empty"><td colspan="10">暂无数据：加载历史后自动回测，或点刷新</td></tr>';
      return;
    }
    tbody.innerHTML = rankings.slice(0, 40).map(r => {
      const statusClass = {
        strong: 'status-strong', active: 'status-active', observing: 'status-observing',
        demoted: 'status-demoted', new: 'status-observing'
      }[r.status] || '';
      return `<tr data-category="${r.category || ''}" data-status="${r.status || ''}">
        <td>${r.rank}</td>
        <td class="plan-name" title="${escapeHtml(r.plan_name)}">${escapeHtml(r.plan_name)}</td>
        <td>${r.category || ''}</td>
        <td>${r.algorithm || ''}</td>
        <td>${rateText(r.rates, 20)}</td>
        <td>${rateText(r.rates, 50)}</td>
        <td>${streakText(r.current_streak)}</td>
        <td>${r.score != null ? Number(r.score).toFixed(1) : '--'}</td>
        <td>${r.weight != null ? Number(r.weight).toFixed(3) : '--'}</td>
        <td><span class="plan-status ${statusClass}">${r.status || ''}</span></td>
      </tr>`;
    }).join('');
    filterPlanTable();
  }

  function renderConsensus() {
    const container = document.getElementById('consensusItems');
    if (!container) return;
    if (!lastConsensus) {
      container.innerHTML = '<div class="consensus-empty">等待数据…</div>';
      return;
    }
    const cats = ['大小', '单双', '区间'];
    container.innerHTML = cats.map(cat => {
      const c = lastConsensus[cat];
      if (!c || !c.effective) {
        return `<div class="consensus-card"><div class="consensus-title">${cat}</div><div class="consensus-empty">暂无共识</div></div>`;
      }
      const bars = Object.keys(c.effective).map(lab => {
        const pct = Math.round((c.effective[lab] || 0) * 100);
        return `<div class="bar-row"><span class="bar-label">${lab}</span>
          <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
          <span class="bar-value">${pct}%</span></div>`;
      }).join('');
      const stars = c.stars ? '★'.repeat(Math.min(c.stars, 5)) : '';
      return `<div class="consensus-card">
        <div class="consensus-title">${cat} <span class="consensus-level">${stars} ${escapeHtml(String(c.label || c.level || ''))}</span></div>
        <div class="consensus-bars">${bars}</div>
        <div class="consensus-meta">加权支持（非真实概率）· 参与: ${c.plan_count || 0} · 分歧: ${c.divergence != null ? (c.divergence * 100).toFixed(0) + '%' : '--'}</div>
      </div>`;
    }).join('');
  }

  function renderHeatmap() {
    const grid = document.getElementById('planHeatmapGrid');
    if (!grid) return;
    if (!grid.children.length) {
      let html = '';
      for (let i = 1; i <= 80; i++) html += `<div class="heat-cell" data-num="${i}">${String(i).padStart(2, '0')}</div>`;
      grid.innerHTML = html;
    }
    if (!lastNumberProb || !lastNumberProb.scores) return;
    const scores = lastNumberProb.scores;
    const maxScore = Math.max(...Object.values(scores), 0.001);
    grid.querySelectorAll('.heat-cell').forEach(cell => {
      const num = parseInt(cell.dataset.num, 10);
      const sc = scores[num] || 0;
      const intensity = sc / maxScore;
      cell.style.background = `rgba(220, 38, 38, ${0.08 + intensity * 0.75})`;
      cell.style.color = intensity > 0.55 ? '#fff' : '';
      cell.title = `号码 ${num}: ${(sc * 100).toFixed(2)}`;
    });
  }

  function renderCombos() {
    const el = document.getElementById('planComboContent');
    if (!el) return;
    if (!lastCombos || !lastCombos.combos || !lastCombos.combos.length) {
      el.innerHTML = '<div class="combo-empty">暂无组合方案</div>';
      return;
    }
    el.innerHTML = lastCombos.combos.map((c, i) => {
      const nums = (c.numbers || c.combo || []).map(n => String(n).padStart(2, '0')).join(' ');
      const name = c.strategy || c.name || ('策略' + (i + 1));
      const score = c.score != null ? Number(c.score).toFixed(3) : '';
      return `<div class="combo-card">
        <div class="combo-header"><span class="combo-name">${escapeHtml(name)}</span><span class="combo-score">${score}</span></div>
        <div class="combo-nums">${nums}</div></div>`;
    }).join('');
    const changeEl = document.getElementById('planChangeRate');
    if (changeEl && lastCombos.change_rate != null) {
      const rate = lastCombos.change_rate * 100;
      let text = `变化度: ${rate.toFixed(1)}%`;
      if (rate < 5) text += ' (稳定)';
      else if (rate < 15) text += ' (正常)';
      else if (rate < 30) text += ' (较大)';
      else text += ' (剧烈)';
      changeEl.textContent = text;
    }
  }

  function renderPlanStats() {
    const el = document.getElementById('planStatsBar');
    if (!el || typeof PlanPool === 'undefined') return;
    try {
      const all = PlanPool.getAllPlans();
      const by = {};
      all.forEach(p => { by[p.status] = (by[p.status] || 0) + 1; });
      const aiSrc = (typeof LocalAI !== 'undefined') ? 'LocalAI' : '无AI';
      el.textContent = `总计: ${all.length} | 活跃: ${by.active || 0} | 强势: ${by.strong || 0} | 观察: ${by.observing || 0} | 降权: ${by.demoted || 0} | 淘汰: ${by.eliminated || 0} | 已结算: ${lastSettledIssue || '--'} | AI: ${aiSrc}`;
    } catch (e) {}
  }

  function filterPlanTable() {
    const cat = (document.getElementById('planFilterCategory') || {}).value || 'all';
    const status = (document.getElementById('planFilterStatus') || {}).value || 'all';
    document.querySelectorAll('#planTableBody tr').forEach(row => {
      if (row.classList.contains('empty')) return;
      const showCat = cat === 'all' || row.dataset.category === cat;
      const showSt = status === 'all' || row.dataset.status === status;
      row.style.display = (showCat && showSt) ? '' : 'none';
    });
  }

  async function forceUpdate() {
    lastUpdateAt = 0;
    fullBacktestDone = false;
    isUpdating = false;
    let rows = (typeof AppState !== 'undefined' && AppState.historyRows) ? AppState.historyRows : [];
    const code = (typeof AppState !== 'undefined' && AppState.currentConfig) ? AppState.currentConfig.code : undefined;

    // 无内存历史时尝试从 CacheDB 拉
    if (rows.length < 10 && typeof CacheDB !== 'undefined' && code) {
      try {
        const cached = await CacheDB.getDrawHistory(code, 500);
        if (cached && cached.length) {
          rows = cached;
          if (typeof AppState !== 'undefined') {
            AppState.historyRows = cached;
            if (AppState.adapter && AppState.adapter.extractSequences) {
              AppState.sequences = AppState.adapter.extractSequences(cached);
            }
          }
          console.log('[PlanIntegration] 从 CacheDB 恢复历史', cached.length);
        }
      } catch (e) {
        console.warn('CacheDB restore', e);
      }
    }

    if (rows.length >= 10) {
      return updateFromHistory(rows, { force: true, lotCode: code });
    }
    showPlanError('无历史数据：请先打开首页并等待开奖数据加载完成，再点刷新');
    return null;
  }

  return {
    updateFromHistory,
    forceUpdate,
    onNewDraw,
    resetForLottery,
    renderPlanPage,
    filterPlanTable,
    saveState,
    getConsensus: () => lastConsensus,
    getRankings: () => lastRankings,
    getNumberProb: () => lastNumberProb,
    getCombos: () => lastCombos,
    isReady: () => initialized,
    getLastSettledIssue: () => lastSettledIssue
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = PlanIntegration;
}
