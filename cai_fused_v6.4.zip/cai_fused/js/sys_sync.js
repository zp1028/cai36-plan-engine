/**
 * sys_sync.js — 系统级数据互通与一键同步 (v6.3)
 * 打通：开奖 → 历史 → 特征 → 首页预测 → 计划引擎 → AI → 战绩 → UI
 */
const SysSync = (function () {
  'use strict';

  let lastSyncAt = 0;

  function lotCode() {
    return (typeof AppState !== 'undefined' && AppState.currentConfig && AppState.currentConfig.code) || '';
  }

  /** 把计划共识刷到首页驾驶舱 */
  function renderHomeCockpit() {
    const el = document.getElementById('homeCockpit');
    if (!el) return;
    if (typeof PlanIntegration === 'undefined') {
      el.innerHTML = '<div class="cockpit-empty">计划引擎未加载</div>';
      return;
    }
    const cons = PlanIntegration.getConsensus && PlanIntegration.getConsensus();
    const ranks = PlanIntegration.getRankings && PlanIntegration.getRankings();
    const combos = PlanIntegration.getCombos && PlanIntegration.getCombos();
    const aiReady = typeof LocalAI !== 'undefined';

    let html = '<div class="cockpit-title">🧭 策略驾驶舱 <span class="cockpit-sub">模型共识≠真实概率</span></div>';

    if (!cons) {
      html += '<div class="cockpit-empty">暂无共识：请先加载历史或打开「计划」页生成</div>';
      el.innerHTML = html;
      return;
    }

    ['大小', '单双', '区间'].forEach(cat => {
      const c = cons[cat];
      if (!c || !c.effective) {
        html += '<div class="cockpit-row"><span class="cockpit-cat">' + cat + '</span><span class="cockpit-muted">无</span></div>';
        return;
      }
      const parts = Object.keys(c.effective).map(k => {
        const pct = Math.round((c.effective[k] || 0) * 100);
        return k + ' ' + pct + '%';
      }).join(' · ');
      const div = c.divergence != null ? Math.round(c.divergence * 100) + '%' : '--';
      html += '<div class="cockpit-row"><span class="cockpit-cat">' + cat + '</span>' +
        '<span class="cockpit-vals">' + parts + '</span>' +
        '<span class="cockpit-div">分歧' + div + '</span></div>';
    });

    const active = (ranks || []).filter(r => r.status === 'active' || r.status === 'strong').length;
    const total = (ranks || []).length;
    html += '<div class="cockpit-meta">参与排名 ' + total + ' · 活跃/强势约 ' + active +
      ' · AI: ' + (aiReady ? 'LocalAI' : '—') + '</div>';

    if (combos && combos.change_rate != null) {
      html += '<div class="cockpit-meta">组合变化度 ' + (combos.change_rate * 100).toFixed(1) + '%</div>';
    }
    if (combos && combos.combos && combos.combos[0]) {
      const nums = (combos.combos[0].numbers || combos.combos[0].combo || []).slice(0, 10)
        .map(n => String(n).padStart(2, '0')).join(' ');
      html += '<div class="cockpit-combo">参考组合(非投注建议): ' + nums + (nums ? ' …' : '—') + '</div>';
    }

    el.innerHTML = html;
  }

  /**
   * 全量同步（新开奖 / 手动刷新）
   * @param {{forcePred?: boolean, forcePlan?: boolean}} opts
   */
  async function syncAll(opts) {
    opts = opts || {};
    if (Date.now() - lastSyncAt < 1500 && !opts.forcePlan && !opts.forcePred) {
      renderHomeCockpit();
      return { skipped: true };
    }
    lastSyncAt = Date.now();

    const rows = (typeof AppState !== 'undefined' && AppState.historyRows) || [];
    const code = lotCode();

    // 1) 计划引擎
    if (typeof PlanIntegration !== 'undefined' && rows.length >= 15) {
      try {
        await PlanIntegration.updateFromHistory(rows, {
          lotCode: code,
          force: !!opts.forcePlan
        });
      } catch (e) {
        console.warn('[SysSync] plan', e);
      }
    }

    // 2) 首页预测
    if (typeof generatePredictions === 'function') {
      try {
        generatePredictions({
          force: !!opts.forcePred,
          reason: opts.forcePred ? 'sys_sync' : 'normal'
        });
      } catch (e) {
        console.warn('[SysSync] pred', e);
      }
    }

    // 3) 战绩 UI
    try {
      if (typeof updateStatsPage === 'function') updateStatsPage();
      if (typeof updateStreakCard === 'function') updateStreakCard();
    } catch (e) {}

    renderHomeCockpit();
    return { ok: true };
  }

  function getAIApiKey() {
    try {
      return localStorage.getItem('cai_ai_api_key') || '';
    } catch (e) {
      return '';
    }
  }

  function setAIApiKey(k) {
    try {
      localStorage.setItem('cai_ai_api_key', k || '');
    } catch (e) {}
  }

  return {
    syncAll,
    renderHomeCockpit,
    getAIApiKey,
    setAIApiKey
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SysSync;
}
