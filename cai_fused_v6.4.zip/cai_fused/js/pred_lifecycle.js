/**
 * pred_lifecycle.js - 预测生命周期 v5.8
 *
 * 架构：
 *  最新开奖 → 检查期号变化 → 更新数据集 → 重建特征
 *  → 模型重评 / 动态权重 → 号码重评分 → 生成组合
 *  → 按「目标期号」冻结，刷新页面不改号码
 *  → 目标期开奖后结算，再生成下一期预测
 *
 * 原则：数据驱动变化，禁止随机/固定号码池制造变化。
 */
const PredLifecycle = (function() {
  'use strict';

  const LS_PREFIX = 'cai_pred_freeze_v1_';

  // 内存态
  let frozen = null; // { lotCode, targetIssue, baseIssue, version, frozenAt, contextHash, snapshot }
  let lastKnownIssue = null;
  let lastTargetIssue = null;

  function storageKey(lotCode, targetIssue) {
    return LS_PREFIX + lotCode + '_' + targetIssue;
  }

  function loadFrozen(lotCode, targetIssue) {
    try {
      const raw = localStorage.getItem(storageKey(lotCode, targetIssue));
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }

  function saveFrozen(entry) {
    try {
      localStorage.setItem(storageKey(entry.lotCode, entry.targetIssue), JSON.stringify(entry));
      // 只保留最近若干期冻结，避免撑爆
      pruneOld(entry.lotCode, entry.targetIssue);
    } catch (e) {
      console.warn('[PredLifecycle] save freeze failed', e);
    }
  }

  function pruneOld(lotCode, keepIssue) {
    try {
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(LS_PREFIX + lotCode + '_')) keys.push(k);
      }
      // 按期号排序，保留最近 30 个
      keys.sort();
      while (keys.length > 30) {
        const drop = keys.shift();
        if (drop && !drop.endsWith('_' + keepIssue)) localStorage.removeItem(drop);
        else break;
      }
    } catch (e) {}
  }

  /**
   * 构建预测上下文（多窗口）—— 每次新期必须重建
   */
  function buildContext(historyRows, liveData) {
    const rows = historyRows || [];
    const n = rows.length;
    const last = n ? rows[n - 1] : null;
    const baseIssue = last ? String(last['期号'] || '') : '';
    const targetIssue = liveData ? String(liveData['下期期号'] || '') : '';
    const lastDraw = last ? (last['号码'] || []) : [];

    function take(k) {
      return rows.slice(Math.max(0, n - k));
    }

    // 指纹：最近 20 期期号 + 号码摘要，用于判断数据是否变化
    const fingerprintParts = take(20).map(r => {
      const nums = (r['号码'] || []).slice(0, 5).join(',');
      return String(r['期号'] || '') + ':' + nums;
    });
    const contextHash = simpleHash(baseIssue + '|' + targetIssue + '|' + fingerprintParts.join(';'));

    return {
      baseIssue,
      targetIssue,
      lastDraw,
      historyLen: n,
      recent_5: take(5),
      recent_10: take(10),
      recent_20: take(20),
      recent_30: take(30),
      recent_50: take(50),
      recent_100: take(100),
      contextHash,
      builtAt: Date.now()
    };
  }

  function simpleHash(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16);
  }

  /**
   * 将最新开奖行合并进 historyRows（若期号更新）
   * @returns {{ changed: boolean, historyRows: Array }}
   */
  function mergeLatestIntoHistory(historyRows, liveRow, adapter) {
    if (!liveRow) return { changed: false, historyRows: historyRows || [] };
    const rows = (historyRows || []).slice();
    const issue = String(liveRow['期号'] || '');
    if (!issue) return { changed: false, historyRows: rows };

    // 已存在则不重复添加
    const exists = rows.some(r => String(r['期号']) === issue);
    if (exists) {
      // 若内容有更新（号码补全）可覆盖最后一条
      if (rows.length && String(rows[rows.length - 1]['期号']) === issue) {
        rows[rows.length - 1] = Object.assign({}, rows[rows.length - 1], liveRow);
      }
      return { changed: false, historyRows: rows };
    }

    // 新期：追加
    rows.push(liveRow);
    // 按期号排序（字符串期号通常可比较）
    rows.sort((a, b) => String(a['期号']).localeCompare(String(b['期号']), undefined, { numeric: true }));
    return { changed: true, historyRows: rows };
  }

  /**
   * 是否需要重新生成预测
   * - 目标期号变了 → 必须重算
   * - 无冻结 → 必须重算
   * - 有冻结且目标期相同 → 不重算（页面刷新保持一致）
   * - force=true → 强制重算（会覆盖冻结，仅调试用）
   */
  function shouldRegenerate(lotCode, targetIssue, force) {
    if (force) return { regenerate: true, reason: 'force' };
    if (!targetIssue) return { regenerate: true, reason: 'no_target' };

    const mem = frozen && frozen.lotCode === lotCode && frozen.targetIssue === targetIssue
      ? frozen : null;
    const disk = mem || loadFrozen(lotCode, targetIssue);

    if (disk && disk.targetIssue === targetIssue && disk.snapshot) {
      frozen = disk;
      return { regenerate: false, reason: 'frozen', entry: disk };
    }
    return { regenerate: true, reason: 'no_freeze' };
  }

  /**
   * 冻结当前预测快照
   */
  function freeze(lotCode, context, snapshot) {
    const version = context.targetIssue + '-v1';
    const entry = {
      lotCode,
      targetIssue: context.targetIssue,
      baseIssue: context.baseIssue,
      prediction_period: context.prediction_period || context.targetIssue,
      cutoff_period: context.cutoff_period || context.baseIssue,
      data_version: context.data_version || null,
      feature_version: context.feature_version || 'F-V1',
      strategy_version: context.strategy_version || 'PLAN-POOL-40-V1',
      version,
      frozenAt: new Date().toISOString(),
      contextHash: context.contextHash,
      historyLen: context.historyLen,
      snapshot
    };
    frozen = entry;
    lastTargetIssue = context.targetIssue;
    lastKnownIssue = context.baseIssue;
    saveFrozen(entry);
    console.log('[PredLifecycle] 冻结预测', version, 'base=', context.baseIssue, 'hash=', context.contextHash);
    return entry;
  }

  /**
   * 取当前冻结（若有）
   */
  function getFrozen(lotCode, targetIssue) {
    if (frozen && frozen.lotCode === lotCode && frozen.targetIssue === targetIssue) return frozen;
    const disk = loadFrozen(lotCode, targetIssue);
    if (disk) frozen = disk;
    return disk;
  }

  /**
   * 标记某目标期已结算（保留记录供历史查看）
   */
  function markSettled(lotCode, targetIssue, actual, hitInfo) {
    const entry = loadFrozen(lotCode, targetIssue) || frozen;
    if (!entry || entry.targetIssue !== targetIssue) return;
    entry.settled = true;
    entry.settledAt = new Date().toISOString();
    entry.actual = actual;
    entry.hitInfo = hitInfo || null;
    try {
      localStorage.setItem(storageKey(lotCode, targetIssue), JSON.stringify(entry));
    } catch (e) {}
    // 若内存冻结的是已结算期，清空以允许生成下一期
    if (frozen && frozen.targetIssue === targetIssue) {
      frozen = null;
    }
  }

  function getStatusBanner() {
    if (!frozen) return null;
    return {
      version: frozen.version,
      targetIssue: frozen.targetIssue,
      baseIssue: frozen.baseIssue,
      frozenAt: frozen.frozenAt,
      settled: !!frozen.settled
    };
  }

  function reset(lotCode) {
    frozen = null;
    lastKnownIssue = null;
    lastTargetIssue = null;
  }

  return {
    buildContext,
    mergeLatestIntoHistory,
    shouldRegenerate,
    freeze,
    getFrozen,
    markSettled,
    getStatusBanner,
    reset,
    getLastKnownIssue: () => lastKnownIssue,
    getLastTargetIssue: () => lastTargetIssue
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = PredLifecycle;
}
