/**
 * data_gate.js — P0 数据可信度闸门 (v6.1 放宽)
 * 仅「致命错误」HOLD；警告不阻断预测/计划
 */
const DataGate = (function () {
  'use strict';

  const REQUIRED_COUNT = 20;
  const MIN_NUM = 1;
  const MAX_NUM = 80;

  function checkDrawRow(row, prevRow) {
    const fatal = [];
    const warnings = [];
    if (!row) {
      fatal.push({ code: 'NULL_ROW', msg: '开奖行为空' });
      return { passed: false, fatal, warnings, fails: fatal };
    }

    const issue = String(row['期号'] || row.issue || '');
    if (!issue) fatal.push({ code: 'NO_ISSUE', msg: '期号缺失' });

    let nums = row['号码'] || row.numbers || row.result || [];
    if (!Array.isArray(nums)) {
      fatal.push({ code: 'NUMS_NOT_ARRAY', msg: '号码不是数组' });
      nums = [];
    }
    const clean = nums.map(n => parseInt(n, 10)).filter(n => !isNaN(n));

    // 个数：非 20 记警告（部分玩法可能不同），仅 0 个致命
    if (clean.length === 0) {
      fatal.push({ code: 'COUNT_ZERO', msg: '号码为空' });
    } else if (clean.length !== REQUIRED_COUNT) {
      warnings.push({ code: 'COUNT', msg: '号码个数 ' + clean.length + '（期望' + REQUIRED_COUNT + '）' });
    }

    const set = new Set();
    for (const n of clean) {
      if (n < MIN_NUM || n > MAX_NUM) {
        fatal.push({ code: 'RANGE', msg: '号码越界: ' + n });
        break;
      }
      if (set.has(n)) {
        warnings.push({ code: 'DUP', msg: '号码重复: ' + n });
        break;
      }
      set.add(n);
    }

    if (prevRow) {
      const prevNums = prevRow['号码'] || prevRow.numbers || [];
      if (Array.isArray(prevNums) && prevNums.length === clean.length && clean.length > 0) {
        const same = clean.every((n, i) => n === parseInt(prevNums[i], 10));
        if (same) warnings.push({ code: 'FIXED_COPY', msg: '与上期号码相同（仅警告）' });
      }
      const prevIssue = String(prevRow['期号'] || prevRow.issue || '');
      if (prevIssue && issue && issue === prevIssue) {
        warnings.push({ code: 'ISSUE_STUCK', msg: '期号与上期相同（仅警告）' });
      }
    }

    return {
      passed: fatal.length === 0,
      fatal,
      warnings,
      fails: fatal, // 兼容旧字段：仅致命
      issue,
      nums: clean
    };
  }

  function runGate(historyRows, liveRow) {
    const rows = historyRows || [];
    const prev = rows.length ? rows[rows.length - 1] : null;
    const checks = [];
    const allFatal = [];
    const allWarn = [];

    if (liveRow) {
      const prevForLive = prev && String(prev['期号']) === String(liveRow['期号'])
        ? (rows[rows.length - 2] || null)
        : prev;
      const r = checkDrawRow(liveRow, prevForLive);
      checks.push({ name: 'live_row', passed: r.passed, fails: r.fatal, warnings: r.warnings });
      allFatal.push(...r.fatal);
      allWarn.push(...(r.warnings || []));
    }

    if (prev) {
      const r2 = checkDrawRow(prev, rows[rows.length - 2] || null);
      checks.push({ name: 'history_tail', passed: r2.passed, fails: r2.fatal, warnings: r2.warnings });
      allFatal.push(...r2.fatal);
      allWarn.push(...(r2.warnings || []));
    }

    // 历史过短：警告，不 HOLD
    if (rows.length < 20) {
      allWarn.push({ code: 'TOO_SHORT', msg: '历史仅 ' + rows.length + ' 期（建议≥30）' });
      checks.push({ name: 'history_len', passed: true, fails: [], warnings: [allWarn[allWarn.length - 1]] });
    } else {
      checks.push({ name: 'history_len', passed: true, fails: [] });
    }

    // 最近样本：仅累计警告
    for (let i = Math.max(0, rows.length - 3); i < rows.length; i++) {
      const r = checkDrawRow(rows[i], i > 0 ? rows[i - 1] : null);
      if (r.fatal.length) {
        allFatal.push(...r.fatal.map(f => Object.assign({}, f, { at: rows[i]['期号'] })));
      }
      if (r.warnings && r.warnings.length) {
        allWarn.push(...r.warnings);
      }
    }
    checks.push({
      name: 'sample_recent',
      passed: allFatal.length === 0,
      fails: allFatal.slice(-5),
      warnings: allWarn.slice(-5)
    });

    const passed = allFatal.length === 0;
    return {
      passed,
      hold: !passed, // 仅致命才 HOLD
      checks,
      warnings: allWarn,
      data_version: 'DATA-V' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' +
        String(rows.length).padStart(4, '0'),
      message: passed
        ? (allWarn.length ? '通过（有 ' + allWarn.length + ' 条警告）' : 'OK')
        : '数据致命错误，预测 HOLD'
    };
  }

  return { checkDrawRow, runGate, REQUIRED_COUNT };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = DataGate;
}
