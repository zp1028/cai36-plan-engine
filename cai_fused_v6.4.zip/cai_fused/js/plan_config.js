/**
 * plan_config.js — 40计划正式冻结表 (Phase 1 / PLAN-POOL-40-V1)
 * 规格：大小6 + 单双6 + 区间6 + 号码10 + 结构6 + AI6
 */
const PlanConfig = (function () {
  'use strict';

  const STRATEGY_VERSION = 'PLAN-POOL-40-V1';

  function baseBinary(o) {
    return Object.assign({
      output_format: 'direction',
      hit_criteria: 'direction_match',
      backtest_windows: [10, 20, 50, 100, 200, 500],
      baseline_type: 'uniform_50',
      baseline_value: 0.50,
      weight_cap: 1.0,
      promote_threshold: { sample: 50, score: 65 },
      demote_threshold: { consecutive_miss: 8 },
      eliminate_threshold: { sample: 100, long_term_below_baseline: true },
      participate_consensus: true,
      participate_combo: false
    }, o);
  }

  function baseZone(o) {
    return Object.assign({
      category: '区间',
      output_format: 'zone_distribution',
      hit_criteria: 'zone_distance',
      backtest_windows: [10, 20, 50, 100, 200, 500],
      baseline_type: 'uniform_zone',
      baseline_value: 0.25,
      weight_cap: 0.8,
      promote_threshold: { sample: 50, score: 60 },
      demote_threshold: { consecutive_miss: 10 },
      eliminate_threshold: { sample: 100, long_term_below_baseline: true },
      participate_consensus: true,
      participate_combo: true
    }, o);
  }

  function baseNumber(o) {
    return Object.assign({
      category: '号码',
      output_format: 'number_scores',
      hit_criteria: 'top20_hit',
      backtest_windows: [10, 20, 50, 100, 200, 500],
      baseline_type: 'uniform_number',
      baseline_value: 0.25,
      weight_cap: 1.0,
      promote_threshold: { sample: 50, score: 60 },
      demote_threshold: { consecutive_miss: 10 },
      eliminate_threshold: { sample: 100, long_term_below_baseline: true },
      participate_consensus: false,
      participate_combo: true
    }, o);
  }

  function baseStruct(o) {
    return Object.assign({
      category: '结构',
      output_format: 'structure_value',
      hit_criteria: 'structure_range',
      backtest_windows: [20, 50, 100, 200],
      baseline_type: 'historical_avg',
      baseline_value: 0.5,
      weight_cap: 0.5,
      promote_threshold: { sample: 50, score: 55 },
      demote_threshold: { consecutive_miss: 12 },
      eliminate_threshold: { sample: 100, long_term_below_baseline: true },
      participate_consensus: false,
      participate_combo: true
    }, o);
  }

  function baseAI(o) {
    return Object.assign({
      category: 'AI',
      window: null,
      input_data: '统一数据包',
      backtest_windows: [10, 20, 50, 100],
      baseline_type: 'uniform_50',
      baseline_value: 0.50,
      weight_cap: 0.3,
      promote_threshold: { sample: 30, score: 65 },
      demote_threshold: { consecutive_miss: 8 },
      eliminate_threshold: { sample: 50, long_term_below_baseline: true },
      participate_consensus: false,
      participate_combo: false
    }, o);
  }

  const PLANS = [
    // ===== 大小 ×6 =====
    baseBinary({ plan_id: 'S-FREQ-010', plan_name: '大小10期频率', category: '大小', algorithm: 'FREQ', window: 10,
      description: '最近10期大/小频率' }),
    baseBinary({ plan_id: 'S-FREQ-020', plan_name: '大小20期频率', category: '大小', algorithm: 'FREQ', window: 20,
      description: '最近20期大/小频率' }),
    baseBinary({ plan_id: 'S-FREQ-050', plan_name: '大小50期频率', category: '大小', algorithm: 'FREQ', window: 50,
      description: '最近50期大/小频率' }),
    baseBinary({ plan_id: 'S-EWMA', plan_name: '大小EWMA', category: '大小', algorithm: 'EWMA', window: 30,
      description: '指数加权大/小' }),
    baseBinary({ plan_id: 'S-MKV1', plan_name: '大小一阶转移', category: '大小', algorithm: 'MKV1', window: 50,
      description: '上一期大/小后的转移比例' }),
    baseBinary({ plan_id: 'S-MULTI', plan_name: '大小多周期融合', category: '大小', algorithm: 'MSF', window: 100,
      description: '10+20+50+100 多窗融合' }),

    // ===== 单双 ×6 =====
    baseBinary({ plan_id: 'D-FREQ-010', plan_name: '单双10期频率', category: '单双', algorithm: 'FREQ', window: 10,
      description: '最近10期单/双频率' }),
    baseBinary({ plan_id: 'D-FREQ-020', plan_name: '单双20期频率', category: '单双', algorithm: 'FREQ', window: 20,
      description: '最近20期单/双频率' }),
    baseBinary({ plan_id: 'D-FREQ-050', plan_name: '单双50期频率', category: '单双', algorithm: 'FREQ', window: 50,
      description: '最近50期单/双频率' }),
    baseBinary({ plan_id: 'D-EWMA', plan_name: '单双EWMA', category: '单双', algorithm: 'EWMA', window: 30,
      description: '指数加权单/双' }),
    baseBinary({ plan_id: 'D-MKV1', plan_name: '单双一阶转移', category: '单双', algorithm: 'MKV1', window: 50,
      description: '上一期单/双后的转移比例' }),
    baseBinary({ plan_id: 'D-MULTI', plan_name: '单双多周期融合', category: '单双', algorithm: 'MSF', window: 100,
      description: '10+20+50+100 多窗融合' }),

    // ===== 区间 ×6 =====
    baseZone({ plan_id: 'Z-FREQ-010', plan_name: '区间10期频率', algorithm: 'FREQ', window: 10,
      description: '四区10期平均分布' }),
    baseZone({ plan_id: 'Z-FREQ-020', plan_name: '区间20期频率', algorithm: 'FREQ', window: 20,
      description: '四区20期平均分布' }),
    baseZone({ plan_id: 'Z-FREQ-050', plan_name: '区间50期频率', algorithm: 'FREQ', window: 50,
      description: '四区50期平均分布' }),
    baseZone({ plan_id: 'Z-FREQ-100', plan_name: '区间100期频率', algorithm: 'FREQ', window: 100,
      description: '四区100期平均分布' }),
    baseZone({ plan_id: 'Z-EWMA', plan_name: '区间EWMA', algorithm: 'EWMA', window: 40,
      description: '四区指数加权分布' }),
    baseZone({ plan_id: 'Z-MULTI', plan_name: '区间多周期融合', algorithm: 'MSF', window: 100,
      description: '多窗区间融合' }),

    // ===== 号码 ×10 =====
    baseNumber({ plan_id: 'N-FREQ-010', plan_name: '号码10期频率', algorithm: 'FREQ', window: 10 }),
    baseNumber({ plan_id: 'N-FREQ-020', plan_name: '号码20期频率', algorithm: 'FREQ', window: 20 }),
    baseNumber({ plan_id: 'N-FREQ-050', plan_name: '号码50期频率', algorithm: 'FREQ', window: 50 }),
    baseNumber({ plan_id: 'N-FREQ-100', plan_name: '号码100期频率', algorithm: 'FREQ', window: 100 }),
    baseNumber({ plan_id: 'N-FREQ-200', plan_name: '号码200期频率', algorithm: 'FREQ', window: 200 }),
    baseNumber({ plan_id: 'N-FREQ-500', plan_name: '号码500期频率', algorithm: 'FREQ', window: 500 }),
    baseNumber({ plan_id: 'N-EWMA', plan_name: '号码EWMA', algorithm: 'EWMA', window: 50 }),
    baseNumber({ plan_id: 'N-OMIT', plan_name: '号码遗漏', algorithm: 'OMIT', window: 80 }),
    baseNumber({ plan_id: 'N-CHOT', plan_name: '号码冷热', algorithm: 'CHOT', window: 50 }),
    baseNumber({ plan_id: 'N-MULTI', plan_name: '号码多周期融合', algorithm: 'MSF', window: 100 }),

    // ===== 结构 ×6 =====
    baseStruct({ plan_id: 'T-REPEAT', plan_name: '重号结构', algorithm: 'STRUCT', window: 30,
      description: '与上期重复个数期望' }),
    baseStruct({ plan_id: 'T-CONSEC', plan_name: '连号结构', algorithm: 'STRUCT', window: 30,
      description: '连号组数/个数' }),
    baseStruct({ plan_id: 'T-TAIL', plan_name: '尾数结构', algorithm: 'STRUCT', window: 50,
      description: '0-9尾分布' }),
    baseStruct({ plan_id: 'T-CHOT', plan_name: '冷热结构', algorithm: 'CHOT', window: 50,
      description: '冷热号码比例' }),
    baseStruct({ plan_id: 'T-ODD', plan_name: '奇偶结构', algorithm: 'FREQ', window: 50,
      description: '整体单双数量结构' }),
    baseStruct({ plan_id: 'T-MULTI', plan_name: '综合结构', algorithm: 'MSF', window: 80,
      description: '多结构指标融合' }),

    // ===== AI ×6（一次API拆六路记账）=====
    baseAI({ plan_id: 'AI-STAT', plan_name: 'AI统计分析', algorithm: 'STAT',
      output_format: 'direction', hit_criteria: 'direction_match',
      participate_consensus: true, ai_role: '统计分析',
      description: '多窗统计辅助评分' }),
    baseAI({ plan_id: 'AI-STRUCT', plan_name: 'AI结构分析', algorithm: 'STRUCT',
      output_format: 'structure_value', hit_criteria: 'structure_match',
      participate_combo: true, ai_role: '结构分析',
      description: '结构候选辅助' }),
    baseAI({ plan_id: 'AI-FILTER', plan_name: 'AI号码筛选', algorithm: 'FILTER',
      output_format: 'number_list', hit_criteria: 'top20_hit',
      participate_combo: true, ai_role: '号码筛选',
      description: '对基础评分重排筛选' }),
    baseAI({ plan_id: 'AI-EVAL', plan_name: 'AI策略评估', algorithm: 'EVAL',
      output_format: 'assessment', hit_criteria: 'eval_accuracy',
      ai_role: '策略评估',
      description: '建议提权/降权（仅记录，不即时改权）' }),
    baseAI({ plan_id: 'AI-ANOM', plan_name: 'AI异常检测', algorithm: 'ANOM',
      output_format: 'anomaly_flag', hit_criteria: 'detection_rate',
      baseline_type: 'none', baseline_value: null, ai_role: '异常检测',
      description: '数据/模型分歧异常' }),
    baseAI({ plan_id: 'AI-SYNTH', plan_name: 'AI综合判断', algorithm: 'SYNTH',
      output_format: 'direction', hit_criteria: 'direction_match',
      participate_consensus: true, participate_combo: true, ai_role: '综合判断',
      description: '综合辅助，影响限幅' })
  ];

  function getPlanById(id) {
    return PLANS.find(p => p.plan_id === id) || null;
  }

  return {
    STRATEGY_VERSION,
    PLANS,
    getPlanById,
    getPlansByCategory: (c) => PLANS.filter(p => p.category === c),
    getConsensusPlans: () => PLANS.filter(p => p.participate_consensus),
    getComboPlans: () => PLANS.filter(p => p.participate_combo),
    getAllPlanIds: () => PLANS.map(p => p.plan_id),
    getPlanCount: () => PLANS.length,
    getCategoryStats: () => {
      const s = {};
      PLANS.forEach(p => { s[p.category] = (s[p.category] || 0) + 1; });
      return s;
    }
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = PlanConfig;
}
