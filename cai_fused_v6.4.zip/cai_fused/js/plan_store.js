/**
 * plan_store.js — 分层持久化 (draw 已由 CacheDB；此处 strategy / prediction / weights)
 * Phase 后续：strategy_history, model_weights, ai_history, prediction_snapshots
 */
const PlanStore = (function () {
  'use strict';

  const DB_NAME = 'CaiPlanStoreDB';
  const DB_VER = 1;
  let dbPromise = null;

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('strategy_history')) {
          const s = db.createObjectStore('strategy_history', { keyPath: 'id', autoIncrement: true });
          s.createIndex('by_lot_issue', ['lotCode', 'issue'], { unique: false });
          s.createIndex('by_plan', 'plan_id', { unique: false });
        }
        if (!db.objectStoreNames.contains('model_weights')) {
          const w = db.createObjectStore('model_weights', { keyPath: 'id', autoIncrement: true });
          w.createIndex('by_lot', 'lotCode', { unique: false });
        }
        if (!db.objectStoreNames.contains('prediction_snapshots')) {
          const p = db.createObjectStore('prediction_snapshots', { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains('ai_history')) {
          const a = db.createObjectStore('ai_history', { keyPath: 'id', autoIncrement: true });
          a.createIndex('by_lot_issue', ['lotCode', 'issue'], { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  function txDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  async function addStrategyRecord(rec) {
    const db = await openDB();
    const tx = db.transaction('strategy_history', 'readwrite');
    tx.objectStore('strategy_history').add(Object.assign({ ts: Date.now() }, rec));
    return txDone(tx);
  }

  async function saveWeightSnapshot(lotCode, issue, weights) {
    const db = await openDB();
    const tx = db.transaction('model_weights', 'readwrite');
    tx.objectStore('model_weights').add({
      lotCode, issue, weights, ts: Date.now()
    });
    return txDone(tx);
  }

  async function savePredictionSnapshot(key, data) {
    const db = await openDB();
    const tx = db.transaction('prediction_snapshots', 'readwrite');
    tx.objectStore('prediction_snapshots').put(Object.assign({ key, ts: Date.now() }, data));
    return txDone(tx);
  }

  async function saveAIHistory(rec) {
    const db = await openDB();
    const tx = db.transaction('ai_history', 'readwrite');
    tx.objectStore('ai_history').add(Object.assign({ ts: Date.now() }, rec));
    return txDone(tx);
  }

  async function listStrategyByIssue(lotCode, issue, limit) {
    limit = limit || 200;
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('strategy_history', 'readonly');
      const idx = tx.objectStore('strategy_history').index('by_lot_issue');
      const req = idx.getAll([lotCode, issue]);
      req.onsuccess = () => resolve((req.result || []).slice(0, limit));
      req.onerror = () => reject(req.error);
    });
  }

  return {
    openDB,
    addStrategyRecord,
    saveWeightSnapshot,
    savePredictionSnapshot,
    saveAIHistory,
    listStrategyByIssue
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = PlanStore;
}
