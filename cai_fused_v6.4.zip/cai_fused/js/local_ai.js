/**
 * local_ai.js — 无 API Key 时的本地结构化「AI」输出（启发式，非真实 LLM）
 * 与 AIPlanManager OUTPUT_SCHEMA 对齐，保证六路计划可回测；有 Key 时仍走 AIPlanManager。
 * 红线：输出为模型评分/倾向，不是真实中奖概率。
 */
const LocalAI = (function () {
  'use strict';

  function clamp01(x) {
    return Math.max(0, Math.min(1, x));
  }

  /**
   * 基于 sequences 末段统计生成 Structured 兼容对象
   */
  function generateStructured(sequences, currentIndex, consensus, rankings) {
    if (!sequences || currentIndex < 5) return null;

    const sizeDir = sequences.sizeDirection || [];
    const oddDir = sequences.oddEvenDirection || [];
    const slice = (arr, n) => arr.slice(Math.max(0, currentIndex - n + 1), currentIndex + 1);

    function freqDir(arr, a, b) {
      const s = slice(arr, 20);
      let ca = 0, cb = 0;
      s.forEach(v => { if (v === a) ca++; else if (v === b) cb++; });
      const t = ca + cb || 1;
      return { a: ca / t, b: cb / t, lean: ca >= cb ? a : b, conf: Math.abs(ca - cb) / t };
    }

    const sz = freqDir(sizeDir, '大', '小');
    const od = freqDir(oddDir, '单', '双');

    // 区间粗略
    const zkeys = ['zone1', 'zone2', 'zone3', 'zone4'];
    const zavg = zkeys.map(k => {
      const s = slice(sequences[k] || [], 30);
      if (!s.length) return 5;
      return s.reduce((a, b) => a + b, 0) / s.length;
    });
    let zsum = zavg.reduce((a, b) => a + b, 0) || 1;
    const zones = zavg.map(v => Math.round(v / zsum * 20));
    // 修正和为20
    let diff = 20 - zones.reduce((a, b) => a + b, 0);
    zones[0] += diff;

    // 号码：近50期频率 top
    const freq = {};
    for (let i = 1; i <= 80; i++) freq[i] = 0;
    const win = slice(sequences.numbers || [], 50);
    let tot = 0;
    win.forEach(draw => {
      (draw || []).forEach(n => { freq[n]++; tot++; });
    });
    const scores = {};
    for (let i = 1; i <= 80; i++) scores[i] = tot ? freq[i] / tot : 1 / 80;
    const top30 = Object.keys(scores)
      .map(n => ({ number: parseInt(n, 10), score: scores[n] }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 30);

    // 策略建议：从 rankings 取 top/bottom
    const rankList = rankings || [];
    const advice_up = rankList.filter(r => (r.score || 0) > 60).slice(0, 3).map(r => r.plan_id);
    const advice_down = rankList.filter(r => (r.score || 0) < 45).slice(0, 3).map(r => r.plan_id);

    // 分歧
    let sizeDiv = 0.5, oddDiv = 0.5;
    if (consensus && consensus['大小'] && consensus['大小'].effective) {
      const e = consensus['大小'].effective;
      const vals = Object.values(e);
      sizeDiv = 1 - Math.max(...vals, 0);
    }
    if (consensus && consensus['单双'] && consensus['单双'].effective) {
      const e = consensus['单双'].effective;
      oddDiv = 1 - Math.max(...Object.values(e), 0);
    }

    return {
      AI01_STAT: {
        size_trend: sz.lean,
        size_confidence: clamp01(0.5 + sz.conf * 0.5),
        odd_even_trend: od.lean,
        odd_even_confidence: clamp01(0.5 + od.conf * 0.5),
        reasoning: 'local_heuristic_freq20'
      },
      AI02_STRUCT: {
        expected_size_count: Math.round(sz.a * 20),
        expected_odd_count: Math.round(od.a * 20),
        zone_distribution: {
          '一区': zones[0], '二区': zones[1], '三区': zones[2], '四区': zones[3]
        },
        reasoning: 'local_zone_avg30'
      },
      AI03_FILTER: {
        top_numbers: top30.slice(0, 20).map(x => x.number),
        scores: top30.slice(0, 20).reduce((o, x) => { o[x.number] = x.score; return o; }, {}),
        reasoning: 'local_freq50'
      },
      AI04_EVAL: {
        promote_candidates: advice_up,
        demote_candidates: advice_down,
        note: '仅建议，不即时改权',
        reasoning: 'local_rank_threshold'
      },
      AI05_ANOM: {
        anomaly_flag: sizeDiv > 0.45 || oddDiv > 0.45,
        size_divergence: sizeDiv,
        odd_divergence: oddDiv,
        reasoning: 'local_consensus_divergence'
      },
      AI06_SYNTH: {
        size_trend: sz.lean,
        size_confidence: clamp01(0.5 + sz.conf * 0.4),
        odd_even_trend: od.lean,
        odd_even_confidence: clamp01(0.5 + od.conf * 0.4),
        top_numbers: top30.slice(0, 15).map(x => x.number),
        overall_confidence: clamp01(1 - (sizeDiv + oddDiv) / 2),
        reasoning: 'local_synth'
      },
      _meta: { source: 'local_ai', model: 'heuristic-v1', prompt_version: 'LOCAL-P01' }
    };
  }

  /**
   * 转为 AIPlanManager.parseAIOutput 可用，或直接预测映射
   */
  function toPlanPredictions(structured, issue, cutoff) {
    if (!structured) return null;
    const s = structured;
    const preds = {};

    // STAT / SYNTH → direction style for 大小（用 size）
    if (s.AI01_STAT) {
      const t = s.AI01_STAT.size_trend;
      const c = s.AI01_STAT.size_confidence || 0.5;
      preds['AI-STAT'] = t === '均衡' ? (c >= 0.5 ? '大' : '小') : t;
    }
    if (s.AI06_SYNTH) {
      const t = s.AI06_SYNTH.size_trend;
      preds['AI-SYNTH'] = t === '均衡' ? '大' : t;
    }
    if (s.AI02_STRUCT && s.AI02_STRUCT.zone_distribution) {
      preds['AI-STRUCT'] = s.AI02_STRUCT.zone_distribution;
    }
    if (s.AI03_FILTER && s.AI03_FILTER.scores) {
      preds['AI-FILTER'] = s.AI03_FILTER.scores;
    }
    if (s.AI04_EVAL) {
      preds['AI-EVAL'] = s.AI04_EVAL;
    }
    if (s.AI05_ANOM) {
      preds['AI-ANOM'] = s.AI05_ANOM.anomaly_flag ? 'anomaly' : 'normal';
    }

    return {
      predictions: preds,
      structured: s,
      input: { prediction_period: issue, cutoff_period: cutoff },
      source: s._meta || { source: 'local_ai' }
    };
  }

  function validateStructured(parsed) {
    const required = ['AI01_STAT', 'AI02_STRUCT', 'AI03_FILTER', 'AI04_EVAL', 'AI05_ANOM', 'AI06_SYNTH'];
    for (const k of required) {
      if (!parsed || !parsed[k]) return { ok: false, reason: 'missing ' + k };
    }
    // 号码范围
    const tops = (parsed.AI03_FILTER.top_numbers || []);
    for (const n of tops) {
      if (n < 1 || n > 80) return { ok: false, reason: 'number OOR' };
    }
    return { ok: true };
  }

  return { generateStructured, toPlanPredictions, validateStructured };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = LocalAI;
}
