# v5.7.2 更新日志 - 计划引擎全量优化

## 本次全部落地

### 1. 实盘自动 settle
- 在 `settlePredictions(rt)` 中调用 `PlanIntegration.onNewDraw`
- 新开奖期号去重后：settle 上一批预测 → 状态机 → 重新 predict → 共识/热力图/组合
- 与 cai31 原有预测结算并行，互不干扰

### 2. 回测性能
- 默认回测窗口 **50 期**（原 80）
- **首次全量 / 之后增量**：`fullBacktestDone` 标记，避免每次刷新重算
- 8 秒节流；「刷新」按钮 `force: true` 可强制全量
- 状态机每 10 期批量一次，降低开销

### 3. 缺失算法
- AI 类（STAT/STRUCT/FILTER/EVAL/ANOM/SYNTH）回测与执行仍跳过（需外部 API）
- 若非 AI 出现未注册算法，自动 **fallback → FREQ**

### 4. 计划状态持久化
- `localStorage` 键：`cai_plan_state_v1_{lotCode}`
- 保存：status / score / weight / sample_size / rates / streak / 最近 120 条 history
- 换彩种 `resetForLottery`；同彩种重启可恢复，跳过重复全量回测

### 5. 底部导航 6 项
- 高度略减、图标 18px、标签 9px、`min-width: 52px`
- 支持横向微滚动，小屏不易挤爆

### 6. 其它
- rates 键兼容 `r20` / `20`
- 排名在无 active 时回退全部非淘汰计划
- 初始 `new` → `observing`，保证共识可参与

## 使用说明

1. 打开 `index.html`，选彩种，等历史加载
2. 首次进入「计划」会自动回测约 50 期（稍后即有评分/命中率）
3. 之后自动刷新只做增量 settle + 预测
4. 刷新页面后计划评分会从 localStorage 恢复
5. 点计划页「刷新」可强制重新全量回测

## 文件

- `js/plan_bridge.js` — v5.7.2 核心
- `js/app.js` — onNewDraw / resetForLottery / 节流
- `css/style.css` — 六项导航适配
