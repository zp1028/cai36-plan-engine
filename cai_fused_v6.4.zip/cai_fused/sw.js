// Service Worker v6.2 - 全量资源，避免旧缓存导致功能缺失
const CACHE_NAME = 'lottery-app-v6.4';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './css/plan_style.css',
  './js/config.js',
  './js/engine.js',
  './js/ewma.js',
  './js/advanced_models.js',
  './js/fusion.js',
  './js/predictors.js',
  './js/predictors_multi.js',
  './js/stats.js',
  './js/period.js',
  './js/storage.js',
  './js/api.js',
  './js/cache.js',
  './js/adapters.js',
  './js/data_gate.js',
  './js/pred_lifecycle.js',
  './js/plan_config.js',
  './js/plan.js',
  './js/plan_pool.js',
  './js/plan_executor.js',
  './js/plan_consensus.js',
  './js/feature_engine.js',
  './js/number_prob.js',
  './js/combo_generator.js',
  './js/data_version.js',
  './js/ai_plan.js',
  './js/local_ai.js',
  './js/plan_store.js',
  './js/plan_bridge.js',
  './js/sys_sync.js',
  './js/app.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(ASSETS).catch(() => {}))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cached) => {
      // 网络优先 JS/CSS，避免功能不同步
      if (event.request.url.match(/\.(js|css)(\?|$)/)) {
        return fetch(event.request).then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then(c => c.put(event.request, copy)).catch(() => {});
          return res;
        }).catch(() => cached || fetch(event.request));
      }
      return cached || fetch(event.request);
    })
  );
});
