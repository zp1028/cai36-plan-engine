# Phase 1 规格冻结摘要（已实现对照）

原则：数据→计划→回测→权重→共识→相对评分→组合

| 模块 | 规格 | 代码 |
|------|------|------|
| P0 闸门 | 10 项检查，失败 HOLD | data_gate.js |
| 40 计划 | PLAN-POOL-40-V1 | plan_config.js |
| 评分 V1 | 30/18/12/12/8/10/10 | plan.js calculateScore |
| 权重波动 | ±15% | plan.js updateWeight |
| 预测冻结 | 同 target 不改写 | pred_lifecycle.js + app.js |
| 时点 | cutoff = 最新已开奖期 | freeze snapshot |
| 共识语义 | 加权支持非真实概率 | UI 文案 |

详见 CHANGELOG_v5.9.md 与对话中的完整冻结稿。
